﻿using System;
using System.Collections.Generic;
using System.Media;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace ApDung2
{
    public partial class Form1 : Form
    {
        // Bảng mật khẩu: Nhóm -> các mật khẩu hợp lệ
        private readonly Dictionary<string, HashSet<string>> _passMap =
            new Dictionary<string, HashSet<string>>(StringComparer.Ordinal)
            {
                { "Phát triển công nghệ", new HashSet<string>{ "1496", "2673" } },
                { "Nghiên cứu viên",     new HashSet<string>{ "7462" } },
                { "Thiết kế mô hình",    new HashSet<string>{ "8884", "3842", "3383" } },
            };

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Cấu hình DataGridView
            dgvLog.AutoGenerateColumns = false;
            dgvLog.Columns.Clear();

            var colTime = new DataGridViewTextBoxColumn
            {
                HeaderText = "Ngày giờ",
                Name = "colTime",
                DataPropertyName = "Time",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
            };
            var colGroup = new DataGridViewTextBoxColumn
            {
                HeaderText = "Nhóm",
                Name = "colGroup",
                DataPropertyName = "Group",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            };
            var colResult = new DataGridViewTextBoxColumn
            {
                HeaderText = "Kết quả",
                Name = "colResult",
                DataPropertyName = "Result",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
            };

            dgvLog.Columns.AddRange(colTime, colGroup, colResult);
            dgvLog.Rows.Clear();

            // Cho phép nhấn Enter trên bàn phím PC để submit
            this.AcceptButton = btnEnter;

            // Chặn nhập ngoài số & Backspace (nếu muốn nhập bàn phím thật)
            txtPassword.KeyPress += (s, ev) =>
            {
                if (char.IsControl(ev.KeyChar)) return;               // Backspace...
                if (char.IsDigit(ev.KeyChar)) return;                 // 0-9
                ev.Handled = true;                                    // chặn ký tự khác
            };
        }

        // Thêm một chữ số vào ô Password (tối đa 4 ký tự)
        private void AppendDigit(string d)
        {
            if (txtPassword.Text.Length < 4)
                txtPassword.Text += d;
        }

        // Xử lý nút số dùng chung
        private void Digit_Click(object sender, EventArgs e)
        {
            if (sender is Button b)
                AppendDigit(b.Text);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtPassword.Clear();
            txtPassword.Focus();
        }

        private void btnRing_Click(object sender, EventArgs e)
        {
            // Mô phỏng chuông báo
            SystemSounds.Exclamation.Play();
            // Bạn có thể log lại nếu muốn:
            dgvLog.Rows.Add(DateTime.Now.ToString("G"), "—", "Chuông!");
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            var input = txtPassword.Text.Trim();

            string group = "Không có";
            string result = "Từ chối!";

            if (TryResolveGroup(input, out string matchedGroup))
            {
                group = matchedGroup;
                result = "Chấp nhận!";
                SystemSounds.Asterisk.Play(); // ting nhẹ khi đúng
            }
            else
            {
                SystemSounds.Hand.Play();     // beep khi sai
            }

            dgvLog.Rows.Add(DateTime.Now.ToString("G"), group, result);

            // Reset để nhập lần tiếp theo
            txtPassword.Clear();
            txtPassword.Focus();
        }

        // Kiểm tra mật khẩu thuộc nhóm nào
        private bool TryResolveGroup(string pass, out string groupName)
        {
            foreach (var kv in _passMap)
            {
                if (kv.Value.Contains(pass))
                {
                    groupName = kv.Key;
                    return true;
                }
            }
            groupName = "Không có";
            return false;
        }
    }
}
