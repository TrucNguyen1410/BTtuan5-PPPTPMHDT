﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1150080078_NguyenLeAnhTruc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Nút Cộng
        private void btnCong_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(txtA.Text.Trim());
                double b = Convert.ToDouble(txtB.Text.Trim());
                txtKetQua.Text = (a + b).ToString();
            }
            catch
            {
                MessageBox.Show("Vui lòng nhập số hợp lệ!");
            }
        }

        // Nút Trừ
        private void btnTru_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(txtA.Text.Trim());
                double b = Convert.ToDouble(txtB.Text.Trim());
                txtKetQua.Text = (a - b).ToString();
            }
            catch
            {
                MessageBox.Show("Vui lòng nhập số hợp lệ!");
            }
        }

        // Nút Nhân
        private void btnNhan_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(txtA.Text.Trim());
                double b = Convert.ToDouble(txtB.Text.Trim());
                txtKetQua.Text = (a * b).ToString();
            }
            catch
            {
                MessageBox.Show("Vui lòng nhập số hợp lệ!");
            }
        }

        // Nút Chia
        private void btnChia_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(txtA.Text.Trim());
                double b = Convert.ToDouble(txtB.Text.Trim());

                if (b == 0)
                {
                    MessageBox.Show("Không thể chia cho 0!");
                    txtB.Clear();
                    txtB.Focus();
                    return;
                }

                txtKetQua.Text = (a / b).ToString();
            }
            catch
            {
                MessageBox.Show("Vui lòng nhập số hợp lệ!");
            }
        }

        // Nút Xóa
        private void btnXoa_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtKetQua.Clear();
            txtA.Focus();
        }

        // Nút Thoát
        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc muốn thoát không?",
                                                  "Xác nhận",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
