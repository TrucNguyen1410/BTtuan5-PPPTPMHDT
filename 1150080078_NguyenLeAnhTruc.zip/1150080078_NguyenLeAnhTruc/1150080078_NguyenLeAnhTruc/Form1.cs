﻿namespace _1150080078_NguyenLeAnhTruc
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.NhapsoA = new System.Windows.Forms.Label();
            this.NhapsoB = new System.Windows.Forms.Label();
            this.ThucHienCacPhepTinh = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtKetQua = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnCong = new System.Windows.Forms.Button();
            this.btnTru = new System.Windows.Forms.Button();
            this.btnNhan = new System.Windows.Forms.Button();
            this.btnChia = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // NhapsoA
            // 
            this.NhapsoA.AutoSize = true;
            this.NhapsoA.Location = new System.Drawing.Point(171, 112);
            this.NhapsoA.Name = "NhapsoA";
            this.NhapsoA.Size = new System.Drawing.Size(72, 16);
            this.NhapsoA.TabIndex = 0;
            this.NhapsoA.Text = "Nhập số a:";
            // 
            // NhapsoB
            // 
            this.NhapsoB.AutoSize = true;
            this.NhapsoB.Location = new System.Drawing.Point(171, 165);
            this.NhapsoB.Name = "NhapsoB";
            this.NhapsoB.Size = new System.Drawing.Size(72, 16);
            this.NhapsoB.TabIndex = 1;
            this.NhapsoB.Text = "Nhập số b:";
            // 
            // ThucHienCacPhepTinh
            // 
            this.ThucHienCacPhepTinh.AutoSize = true;
            this.ThucHienCacPhepTinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.ThucHienCacPhepTinh.Location = new System.Drawing.Point(269, 52);
            this.ThucHienCacPhepTinh.Name = "ThucHienCacPhepTinh";
            this.ThucHienCacPhepTinh.Size = new System.Drawing.Size(286, 18);
            this.ThucHienCacPhepTinh.TabIndex = 2;
            this.ThucHienCacPhepTinh.Text = "THỰC HIỆN CÁC PHÉP TÍNH SỐ HỌC";
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(262, 109);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(314, 22);
            this.txtA.TabIndex = 3;
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(262, 162);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(314, 22);
            this.txtB.TabIndex = 4;
            // 
            // txtKetQua
            // 
            this.txtKetQua.Location = new System.Drawing.Point(262, 299);
            this.txtKetQua.Name = "txtKetQua";
            this.txtKetQua.Size = new System.Drawing.Size(314, 22);
            this.txtKetQua.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(188, 302);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Kết quả:";
            // 
            // btnCong
            // 
            this.btnCong.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnCong.Location = new System.Drawing.Point(191, 229);
            this.btnCong.Name = "btnCong";
            this.btnCong.Size = new System.Drawing.Size(80, 26);
            this.btnCong.TabIndex = 7;
            this.btnCong.Text = "Cộng";
            this.btnCong.UseVisualStyleBackColor = false;
            this.btnCong.Click += new System.EventHandler(this.btnCong_Click);
            // 
            // btnTru
            // 
            this.btnTru.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnTru.Location = new System.Drawing.Point(311, 229);
            this.btnTru.Name = "btnTru";
            this.btnTru.Size = new System.Drawing.Size(80, 26);
            this.btnTru.TabIndex = 8;
            this.btnTru.Text = "Trừ";
            this.btnTru.UseVisualStyleBackColor = false;
            this.btnTru.Click += new System.EventHandler(this.btnTru_Click);
            // 
            // btnNhan
            // 
            this.btnNhan.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnNhan.Location = new System.Drawing.Point(442, 229);
            this.btnNhan.Name = "btnNhan";
            this.btnNhan.Size = new System.Drawing.Size(80, 26);
            this.btnNhan.TabIndex = 9;
            this.btnNhan.Text = "Nhân";
            this.btnNhan.UseVisualStyleBackColor = false;
            this.btnNhan.Click += new System.EventHandler(this.btnNhan_Click);
            // 
            // btnChia
            // 
            this.btnChia.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnChia.Location = new System.Drawing.Point(563, 229);
            this.btnChia.Name = "btnChia";
            this.btnChia.Size = new System.Drawing.Size(80, 26);
            this.btnChia.TabIndex = 10;
            this.btnChia.Text = "Chia";
            this.btnChia.UseVisualStyleBackColor = false;
            this.btnChia.Click += new System.EventHandler(this.btnChia_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnXoa.Location = new System.Drawing.Point(272, 365);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(80, 26);
            this.btnXoa.TabIndex = 11;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnThoat.Location = new System.Drawing.Point(458, 365);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(80, 26);
            this.btnThoat.TabIndex = 12;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = false;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnChia);
            this.Controls.Add(this.btnNhan);
            this.Controls.Add(this.btnTru);
            this.Controls.Add(this.btnCong);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtKetQua);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.ThucHienCacPhepTinh);
            this.Controls.Add(this.NhapsoB);
            this.Controls.Add(this.NhapsoA);
            this.Name = "Form1";
            this.Text = "Thực hành 1";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label NhapsoA;
        private System.Windows.Forms.Label NhapsoB;
        private System.Windows.Forms.Label ThucHienCacPhepTinh;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtKetQua;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnCong;
        private System.Windows.Forms.Button btnTru;
        private System.Windows.Forms.Button btnNhan;
        private System.Windows.Forms.Button btnChia;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThoat;
    }
}
