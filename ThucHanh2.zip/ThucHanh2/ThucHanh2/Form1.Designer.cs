﻿namespace ThucHanh2
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.GroupBox grpKhachHang;
        private System.Windows.Forms.Label lblTenKH;
        private System.Windows.Forms.TextBox txtTenKH;

        private System.Windows.Forms.GroupBox grpDichVu;
        private System.Windows.Forms.CheckBox chkLayCaoRang;
        private System.Windows.Forms.CheckBox chkTayTrangRang;
        private System.Windows.Forms.CheckBox chkHanRang;
        private System.Windows.Forms.CheckBox chkBeRang;
        private System.Windows.Forms.CheckBox chkBocRang;

        private System.Windows.Forms.Label lblGiaLayCao;
        private System.Windows.Forms.Label lblGiaTayTrang;
        private System.Windows.Forms.Label lblGiaHan;
        private System.Windows.Forms.Label lblGiaBe;
        private System.Windows.Forms.Label lblGiaBoc;

        private System.Windows.Forms.NumericUpDown nupHanRang;
        private System.Windows.Forms.NumericUpDown nupBeRang;
        private System.Windows.Forms.NumericUpDown nupBocRang;

        private System.Windows.Forms.Label lblKetQua;
        private System.Windows.Forms.TextBox txtThanhTien;

        private System.Windows.Forms.GroupBox grpChucNang;
        private System.Windows.Forms.Button btnTinhTien;
        private System.Windows.Forms.Button btnThoat;

        private System.Windows.Forms.ErrorProvider err;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            this.lblHeader = new System.Windows.Forms.Label();
            this.grpKhachHang = new System.Windows.Forms.GroupBox();
            this.lblTenKH = new System.Windows.Forms.Label();
            this.txtTenKH = new System.Windows.Forms.TextBox();

            this.grpDichVu = new System.Windows.Forms.GroupBox();
            this.chkLayCaoRang = new System.Windows.Forms.CheckBox();
            this.chkTayTrangRang = new System.Windows.Forms.CheckBox();
            this.chkHanRang = new System.Windows.Forms.CheckBox();
            this.chkBeRang = new System.Windows.Forms.CheckBox();
            this.chkBocRang = new System.Windows.Forms.CheckBox();

            this.lblGiaLayCao = new System.Windows.Forms.Label();
            this.lblGiaTayTrang = new System.Windows.Forms.Label();
            this.lblGiaHan = new System.Windows.Forms.Label();
            this.lblGiaBe = new System.Windows.Forms.Label();
            this.lblGiaBoc = new System.Windows.Forms.Label();

            this.nupHanRang = new System.Windows.Forms.NumericUpDown();
            this.nupBeRang = new System.Windows.Forms.NumericUpDown();
            this.nupBocRang = new System.Windows.Forms.NumericUpDown();

            this.lblKetQua = new System.Windows.Forms.Label();
            this.txtThanhTien = new System.Windows.Forms.TextBox();

            this.grpChucNang = new System.Windows.Forms.GroupBox();
            this.btnTinhTien = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();

            this.err = new System.Windows.Forms.ErrorProvider(this.components);

            this.grpKhachHang.SuspendLayout();
            this.grpDichVu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupHanRang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupBeRang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupBocRang)).BeginInit();
            this.grpChucNang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.err)).BeginInit();
            this.SuspendLayout();

            // ===== Header =====
            this.lblHeader.BackColor = System.Drawing.Color.LimeGreen;
            this.lblHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.White;
            this.lblHeader.Location = new System.Drawing.Point(0, 0);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Padding = new System.Windows.Forms.Padding(10, 5, 0, 5);
            this.lblHeader.Size = new System.Drawing.Size(720, 55);
            this.lblHeader.TabIndex = 0;
            this.lblHeader.Text = "PHÒNG KHÁM NHA KHOA HẢI ÂU";
            this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // ===== Group: Khách hàng =====
            this.grpKhachHang.Controls.Add(this.lblTenKH);
            this.grpKhachHang.Controls.Add(this.txtTenKH);
            this.grpKhachHang.Location = new System.Drawing.Point(12, 62);
            this.grpKhachHang.Name = "grpKhachHang";
            this.grpKhachHang.Size = new System.Drawing.Size(696, 70);
            this.grpKhachHang.TabIndex = 1;
            this.grpKhachHang.TabStop = false;
            this.grpKhachHang.Text = "Tên khách hàng:";

            this.lblTenKH.AutoSize = true;
            this.lblTenKH.Location = new System.Drawing.Point(16, 32);
            this.lblTenKH.Name = "lblTenKH";
            this.lblTenKH.Size = new System.Drawing.Size(28, 16);
            this.lblTenKH.Text = "Tên";

            this.txtTenKH.Location = new System.Drawing.Point(60, 28);
            this.txtTenKH.Name = "txtTenKH";
            this.txtTenKH.Size = new System.Drawing.Size(610, 22);
            this.txtTenKH.TabIndex = 0;
            this.txtTenKH.Validating += new System.ComponentModel.CancelEventHandler(this.txtTenKH_Validating);
            this.txtTenKH.TextChanged += new System.EventHandler(this.txtTenKH_TextChanged);

            // ===== Group: Dịch vụ =====
            this.grpDichVu.Controls.Add(this.chkLayCaoRang);
            this.grpDichVu.Controls.Add(this.chkTayTrangRang);
            this.grpDichVu.Controls.Add(this.chkHanRang);
            this.grpDichVu.Controls.Add(this.chkBeRang);
            this.grpDichVu.Controls.Add(this.chkBocRang);

            this.grpDichVu.Controls.Add(this.lblGiaLayCao);
            this.grpDichVu.Controls.Add(this.lblGiaTayTrang);
            this.grpDichVu.Controls.Add(this.lblGiaHan);
            this.grpDichVu.Controls.Add(this.lblGiaBe);
            this.grpDichVu.Controls.Add(this.lblGiaBoc);

            this.grpDichVu.Controls.Add(this.nupHanRang);
            this.grpDichVu.Controls.Add(this.nupBeRang);
            this.grpDichVu.Controls.Add(this.nupBocRang);

            this.grpDichVu.Location = new System.Drawing.Point(12, 138);
            this.grpDichVu.Name = "grpDichVu";
            this.grpDichVu.Size = new System.Drawing.Size(696, 178);
            this.grpDichVu.TabIndex = 2;
            this.grpDichVu.TabStop = false;
            this.grpDichVu.Text = "Dịch vụ tại phòng khám:";

            // Checkboxes (trái)
            this.chkLayCaoRang.AutoSize = true;
            this.chkLayCaoRang.Location = new System.Drawing.Point(20, 32);
            this.chkLayCaoRang.Name = "chkLayCaoRang";
            this.chkLayCaoRang.Size = new System.Drawing.Size(113, 20);
            this.chkLayCaoRang.TabIndex = 0;
            this.chkLayCaoRang.Text = "Lấy cao răng";
            this.chkLayCaoRang.UseVisualStyleBackColor = true;

            this.chkTayTrangRang.AutoSize = true;
            this.chkTayTrangRang.Location = new System.Drawing.Point(20, 62);
            this.chkTayTrangRang.Name = "chkTayTrangRang";
            this.chkTayTrangRang.Size = new System.Drawing.Size(124, 20);
            this.chkTayTrangRang.TabIndex = 1;
            this.chkTayTrangRang.Text = "Tẩy trắng răng";
            this.chkTayTrangRang.UseVisualStyleBackColor = true;

            this.chkHanRang.AutoSize = true;
            this.chkHanRang.Location = new System.Drawing.Point(20, 92);
            this.chkHanRang.Name = "chkHanRang";
            this.chkHanRang.Size = new System.Drawing.Size(87, 20);
            this.chkHanRang.TabIndex = 2;
            this.chkHanRang.Text = "Hàn răng";
            this.chkHanRang.UseVisualStyleBackColor = true;
            this.chkHanRang.CheckedChanged += new System.EventHandler(this.chkHanRang_CheckedChanged);

            this.chkBeRang.AutoSize = true;
            this.chkBeRang.Location = new System.Drawing.Point(20, 122);
            this.chkBeRang.Name = "chkBeRang";
            this.chkBeRang.Size = new System.Drawing.Size(79, 20);
            this.chkBeRang.TabIndex = 3;
            this.chkBeRang.Text = "Bẻ răng";
            this.chkBeRang.UseVisualStyleBackColor = true;
            this.chkBeRang.CheckedChanged += new System.EventHandler(this.chkBeRang_CheckedChanged);

            this.chkBocRang.AutoSize = true;
            this.chkBocRang.Location = new System.Drawing.Point(20, 152);
            this.chkBocRang.Name = "chkBocRang";
            this.chkBocRang.Size = new System.Drawing.Size(86, 20);
            this.chkBocRang.TabIndex = 4;
            this.chkBocRang.Text = "Bọc răng";
            this.chkBocRang.UseVisualStyleBackColor = true;
            this.chkBocRang.CheckedChanged += new System.EventHandler(this.chkBocRang_CheckedChanged);

            // Giá (phải)
            this.lblGiaLayCao.AutoSize = true;
            this.lblGiaLayCao.Location = new System.Drawing.Point(220, 33);
            this.lblGiaLayCao.Name = "lblGiaLayCao";
            this.lblGiaLayCao.Size = new System.Drawing.Size(118, 16);
            this.lblGiaLayCao.Text = "50.000đ / 2 hàm";

            this.lblGiaTayTrang.AutoSize = true;
            this.lblGiaTayTrang.Location = new System.Drawing.Point(220, 63);
            this.lblGiaTayTrang.Name = "lblGiaTayTrang";
            this.lblGiaTayTrang.Size = new System.Drawing.Size(135, 16);
            this.lblGiaTayTrang.Text = "100.000đ / 2 hàm";

            this.lblGiaHan.AutoSize = true;
            this.lblGiaHan.Location = new System.Drawing.Point(220, 93);
            this.lblGiaHan.Name = "lblGiaHan";
            this.lblGiaHan.Size = new System.Drawing.Size(122, 16);
            this.lblGiaHan.Text = "100.000đ / 1 răng";

            this.lblGiaBe.AutoSize = true;
            this.lblGiaBe.Location = new System.Drawing.Point(220, 123);
            this.lblGiaBe.Name = "lblGiaBe";
            this.lblGiaBe.Size = new System.Drawing.Size(111, 16);
            this.lblGiaBe.Text = "10.000đ / 1 răng";

            this.lblGiaBoc.AutoSize = true;
            this.lblGiaBoc.Location = new System.Drawing.Point(220, 153);
            this.lblGiaBoc.Name = "lblGiaBoc";
            this.lblGiaBoc.Size = new System.Drawing.Size(143, 16);
            this.lblGiaBoc.Text = "1.000.000đ / 1 răng";

            // NumericUpDown (số lượng)
            this.nupHanRang.Location = new System.Drawing.Point(620, 90);
            this.nupHanRang.Minimum = 1;
            this.nupHanRang.Maximum = 50;
            this.nupHanRang.Name = "nupHanRang";
            this.nupHanRang.Size = new System.Drawing.Size(55, 22);
            this.nupHanRang.TabIndex = 5;

            this.nupBeRang.Location = new System.Drawing.Point(620, 120);
            this.nupBeRang.Minimum = 1;
            this.nupBeRang.Maximum = 50;
            this.nupBeRang.Name = "nupBeRang";
            this.nupBeRang.Size = new System.Drawing.Size(55, 22);
            this.nupBeRang.TabIndex = 6;

            this.nupBocRang.Location = new System.Drawing.Point(620, 150);
            this.nupBocRang.Minimum = 1;
            this.nupBocRang.Maximum = 50;
            this.nupBocRang.Name = "nupBocRang";
            this.nupBocRang.Size = new System.Drawing.Size(55, 22);
            this.nupBocRang.TabIndex = 7;

            // ===== Kết quả =====
            this.lblKetQua.AutoSize = true;
            this.lblKetQua.Location = new System.Drawing.Point(22, 328);
            this.lblKetQua.Name = "lblKetQua";
            this.lblKetQua.Size = new System.Drawing.Size(59, 16);
            this.lblKetQua.Text = "Kết quả:";

            this.txtThanhTien.Location = new System.Drawing.Point(100, 325);
            this.txtThanhTien.Name = "txtThanhTien";
            this.txtThanhTien.ReadOnly = true;
            this.txtThanhTien.Size = new System.Drawing.Size(300, 22);
            this.txtThanhTien.TabIndex = 3;
            this.txtThanhTien.TabStop = false;
            this.txtThanhTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;

            // ===== Group: Chức năng =====
            this.grpChucNang.Controls.Add(this.btnTinhTien);
            this.grpChucNang.Controls.Add(this.btnThoat);
            this.grpChucNang.Location = new System.Drawing.Point(12, 357);
            this.grpChucNang.Name = "grpChucNang";
            this.grpChucNang.Size = new System.Drawing.Size(696, 70);
            this.grpChucNang.TabIndex = 4;
            this.grpChucNang.TabStop = false;
            this.grpChucNang.Text = "Chức năng:";

            this.btnTinhTien.Location = new System.Drawing.Point(140, 25);
            this.btnTinhTien.Name = "btnTinhTien";
            this.btnTinhTien.Size = new System.Drawing.Size(120, 30);
            this.btnTinhTien.TabIndex = 0;
            this.btnTinhTien.Text = "Tính tiền";
            this.btnTinhTien.UseVisualStyleBackColor = true;
            this.btnTinhTien.Click += new System.EventHandler(this.btnTinhTien_Click);

            this.btnThoat.Location = new System.Drawing.Point(420, 25);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(120, 30);
            this.btnThoat.TabIndex = 1;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);

            // ===== ErrorProvider =====
            this.err.ContainerControl = this;

            // ===== Form =====
            this.AcceptButton = this.btnTinhTien;
            this.CancelButton = this.btnThoat;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(720, 445);
            this.Controls.Add(this.grpChucNang);
            this.Controls.Add(this.txtThanhTien);
            this.Controls.Add(this.lblKetQua);
            this.Controls.Add(this.grpDichVu);
            this.Controls.Add(this.grpKhachHang);
            this.Controls.Add(this.lblHeader);
            this.Name = "Form1";
            this.Text = "Tính tiền dịch vụ nha khoa";
            this.Load += new System.EventHandler(this.Form1_Load);

            this.grpKhachHang.ResumeLayout(false);
            this.grpKhachHang.PerformLayout();
            this.grpDichVu.ResumeLayout(false);
            this.grpDichVu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupHanRang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupBeRang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupBocRang)).EndInit();
            this.grpChucNang.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.err)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
