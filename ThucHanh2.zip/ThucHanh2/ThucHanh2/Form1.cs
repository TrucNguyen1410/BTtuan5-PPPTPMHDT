﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Forms;

namespace ThucHanh2
{
    public partial class Form1 : Form
    {
        // Đơn giá (đồng)
        private const decimal GIA_LAY_CAO_RANG = 50_000m;
        private const decimal GIA_TAY_TRANG_RANG = 100_000m;
        private const decimal GIA_HAN_RANG = 100_000m;   // /1 răng
        private const decimal GIA_BE_RANG = 10_000m;    // /1 răng
        private const decimal GIA_BOC_RANG = 1_000_000m; // /1 răng

        private readonly CultureInfo _vi = CultureInfo.GetCultureInfo("vi-VN");

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // ban đầu tắt số lượng với các dịch vụ tính theo răng
            nupHanRang.Enabled = chkHanRang.Checked;
            nupBeRang.Enabled = chkBeRang.Checked;
            nupBocRang.Enabled = chkBocRang.Checked;

            // mặc định số lượng = 1
            nupHanRang.Value = nupBeRang.Value = nupBocRang.Value = 1;

            txtTenKH.Focus();
        }

        // ====== Validate tên khách hàng ======
        private void txtTenKH_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTenKH.Text))
            {
                e.Cancel = true;
                err.SetError(txtTenKH, "Dữ liệu không được để trống!");
            }
            else
            {
                e.Cancel = false;
                err.SetError(txtTenKH, null);
            }
        }

        private void txtTenKH_TextChanged(object sender, EventArgs e)
        {
            // xóa cảnh báo ngay khi người dùng gõ lại
            if (!string.IsNullOrWhiteSpace(txtTenKH.Text))
                err.SetError(txtTenKH, null);
        }

        // ====== Bật/tắt NumericUpDown theo checkbox ======
        private void chkHanRang_CheckedChanged(object sender, EventArgs e)
        {
            nupHanRang.Enabled = chkHanRang.Checked;
        }

        private void chkBeRang_CheckedChanged(object sender, EventArgs e)
        {
            nupBeRang.Enabled = chkBeRang.Checked;
        }

        private void chkBocRang_CheckedChanged(object sender, EventArgs e)
        {
            nupBocRang.Enabled = chkBocRang.Checked;
        }

        // ====== TÍNH TIỀN ======
        private void btnTinhTien_Click(object sender, EventArgs e)
        {
            // Kích hoạt Validate cho các control có Validating
            if (!ValidateChildren(ValidationConstraints.Enabled)) return;

            decimal thanhTien = 0m;

            if (chkLayCaoRang.Checked)
                thanhTien += GIA_LAY_CAO_RANG;

            if (chkTayTrangRang.Checked)
                thanhTien += GIA_TAY_TRANG_RANG;

            if (chkHanRang.Checked)
                thanhTien += nupHanRang.Value * GIA_HAN_RANG;

            if (chkBeRang.Checked)
                thanhTien += nupBeRang.Value * GIA_BE_RANG;

            if (chkBocRang.Checked)
                thanhTien += nupBocRang.Value * GIA_BOC_RANG;

            // Hiển thị theo định dạng tiền Việt
            txtThanhTien.Text = string.Format(_vi, "{0:N0} đ", thanhTien);
        }

        // ====== THOÁT ======
        private void btnThoat_Click(object sender, EventArgs e)
        {
            var ask = MessageBox.Show("Bạn có chắc muốn thoát?", "Xác nhận",
                                      MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (ask == DialogResult.Yes) this.Close();
        }
    }
}
