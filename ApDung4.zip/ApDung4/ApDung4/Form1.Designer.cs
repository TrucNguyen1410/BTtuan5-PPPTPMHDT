﻿namespace ApDung4
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ListBox lstMatHang;
        private System.Windows.Forms.ListBox lstDaChon;
        private System.Windows.Forms.Label lblDanhSach;
        private System.Windows.Forms.Label lblLuaChon;
        private System.Windows.Forms.Button btnChuyen1;
        private System.Windows.Forms.Button btnChuyenHet1;
        private System.Windows.Forms.Button btnChuyen2;
        private System.Windows.Forms.Button btnChuyenHet2;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lstMatHang = new System.Windows.Forms.ListBox();
            this.lstDaChon = new System.Windows.Forms.ListBox();
            this.lblDanhSach = new System.Windows.Forms.Label();
            this.lblLuaChon = new System.Windows.Forms.Label();
            this.btnChuyen1 = new System.Windows.Forms.Button();
            this.btnChuyenHet1 = new System.Windows.Forms.Button();
            this.btnChuyen2 = new System.Windows.Forms.Button();
            this.btnChuyenHet2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstMatHang
            // 
            this.lstMatHang.FormattingEnabled = true;
            this.lstMatHang.ItemHeight = 16;
            this.lstMatHang.Location = new System.Drawing.Point(20, 50);
            this.lstMatHang.Name = "lstMatHang";
            this.lstMatHang.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstMatHang.Size = new System.Drawing.Size(200, 260);
            this.lstMatHang.TabIndex = 0;
            // 
            // lstDaChon
            // 
            this.lstDaChon.FormattingEnabled = true;
            this.lstDaChon.ItemHeight = 16;
            this.lstDaChon.Location = new System.Drawing.Point(380, 50);
            this.lstDaChon.Name = "lstDaChon";
            this.lstDaChon.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstDaChon.Size = new System.Drawing.Size(200, 260);
            this.lstDaChon.TabIndex = 1;
            // 
            // lblDanhSach
            // 
            this.lblDanhSach.AutoSize = true;
            this.lblDanhSach.Location = new System.Drawing.Point(20, 20);
            this.lblDanhSach.Name = "lblDanhSach";
            this.lblDanhSach.Size = new System.Drawing.Size(156, 16);
            this.lblDanhSach.TabIndex = 2;
            this.lblDanhSach.Text = "Danh sách các mặt hàng";
            // 
            // lblLuaChon
            // 
            this.lblLuaChon.AutoSize = true;
            this.lblLuaChon.Location = new System.Drawing.Point(380, 20);
            this.lblLuaChon.Name = "lblLuaChon";
            this.lblLuaChon.Size = new System.Drawing.Size(158, 16);
            this.lblLuaChon.TabIndex = 3;
            this.lblLuaChon.Text = "Các mặt hàng lựa chọn";
            // 
            // btnChuyen1
            // 
            this.btnChuyen1.Location = new System.Drawing.Point(260, 80);
            this.btnChuyen1.Name = "btnChuyen1";
            this.btnChuyen1.Size = new System.Drawing.Size(90, 30);
            this.btnChuyen1.TabIndex = 4;
            this.btnChuyen1.Text = ">";
            this.btnChuyen1.UseVisualStyleBackColor = true;
            this.btnChuyen1.Click += new System.EventHandler(this.btnChuyen1_Click);
            // 
            // btnChuyenHet1
            // 
            this.btnChuyenHet1.Location = new System.Drawing.Point(260, 130);
            this.btnChuyenHet1.Name = "btnChuyenHet1";
            this.btnChuyenHet1.Size = new System.Drawing.Size(90, 30);
            this.btnChuyenHet1.TabIndex = 5;
            this.btnChuyenHet1.Text = ">>";
            this.btnChuyenHet1.UseVisualStyleBackColor = true;
            this.btnChuyenHet1.Click += new System.EventHandler(this.btnChuyenHet1_Click);
            // 
            // btnChuyen2
            // 
            this.btnChuyen2.Location = new System.Drawing.Point(260, 180);
            this.btnChuyen2.Name = "btnChuyen2";
            this.btnChuyen2.Size = new System.Drawing.Size(90, 30);
            this.btnChuyen2.TabIndex = 6;
            this.btnChuyen2.Text = "<";
            this.btnChuyen2.UseVisualStyleBackColor = true;
            this.btnChuyen2.Click += new System.EventHandler(this.btnChuyen2_Click);
            // 
            // btnChuyenHet2
            // 
            this.btnChuyenHet2.Location = new System.Drawing.Point(260, 230);
            this.btnChuyenHet2.Name = "btnChuyenHet2";
            this.btnChuyenHet2.Size = new System.Drawing.Size(90, 30);
            this.btnChuyenHet2.TabIndex = 7;
            this.btnChuyenHet2.Text = "<<";
            this.btnChuyenHet2.UseVisualStyleBackColor = true;
            this.btnChuyenHet2.Click += new System.EventHandler(this.btnChuyenHet2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 330);
            this.Controls.Add(this.btnChuyenHet2);
            this.Controls.Add(this.btnChuyen2);
            this.Controls.Add(this.btnChuyenHet1);
            this.Controls.Add(this.btnChuyen1);
            this.Controls.Add(this.lblLuaChon);
            this.Controls.Add(this.lblDanhSach);
            this.Controls.Add(this.lstDaChon);
            this.Controls.Add(this.lstMatHang);
            this.Name = "Form1";
            this.Text = "Bài tập 7";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
