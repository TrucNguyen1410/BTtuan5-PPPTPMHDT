﻿using System;
using System.Windows.Forms;

namespace ApDung4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Khởi tạo danh sách mặt hàng
            lstMatHang.Items.Add("CPU");
            lstMatHang.Items.Add("MainBoard");
            lstMatHang.Items.Add("RAM");
            lstMatHang.Items.Add("Keyboard");
            lstMatHang.Items.Add("Mouse");
            lstMatHang.Items.Add("NIC");
            lstMatHang.Items.Add("FAN");
        }

        private void btnChuyen1_Click(object sender, EventArgs e)
        {
            // chuyển các item được chọn từ trái sang phải
            while (lstMatHang.SelectedItems.Count > 0)
            {
                object item = lstMatHang.SelectedItems[0];
                lstDaChon.Items.Add(item);
                lstMatHang.Items.Remove(item);
            }
        }

        private void btnChuyenHet1_Click(object sender, EventArgs e)
        {
            // chuyển toàn bộ từ trái sang phải
            foreach (var item in lstMatHang.Items)
            {
                lstDaChon.Items.Add(item);
            }
            lstMatHang.Items.Clear();
        }

        private void btnChuyen2_Click(object sender, EventArgs e)
        {
            // chuyển các item được chọn từ phải sang trái
            while (lstDaChon.SelectedItems.Count > 0)
            {
                object item = lstDaChon.SelectedItems[0];
                lstMatHang.Items.Add(item);
                lstDaChon.Items.Remove(item);
            }
        }

        private void btnChuyenHet2_Click(object sender, EventArgs e)
        {
            // chuyển toàn bộ từ phải sang trái
            foreach (var item in lstDaChon.Items)
            {
                lstMatHang.Items.Add(item);
            }
            lstDaChon.Items.Clear();
        }
    }
}
