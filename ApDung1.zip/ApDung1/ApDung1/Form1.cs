﻿using System;
using System.Windows.Forms;

namespace ApDung1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Tuỳ chọn: chọn USCLN mặc định
            rdoUSCLN.Checked = true;
        }

        // ====== HÀM TÍNH TOÁN CỐT LÕI ======

        // USCLN (Greatest Common Divisor) - Thuật toán Euclid
        private static long GCD(long a, long b)
        {
            a = Math.Abs(a);
            b = Math.Abs(b);
            if (a == 0) return b;
            if (b == 0) return a;
            while (b != 0)
            {
                long r = a % b;
                a = b;
                b = r;
            }
            return a;
        }

        // BSCNN (Least Common Multiple)
        private static long LCM(long a, long b)
        {
            if (a == 0 || b == 0) return 0; // quy ước: nếu có số 0 thì BSCNN = 0
            long gcd = GCD(a, b);
            // Tránh tràn: chia trước rồi mới nhân
            return Math.Abs(a / gcd * b);
        }

        // ====== XỬ LÝ NÚT TÌM ======
        private void btnTim_Click(object sender, EventArgs e)
        {
            // Kiểm tra đầu vào
            if (!long.TryParse(txtA.Text.Trim(), out long a))
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ cho a!", "Lỗi nhập liệu");
                txtA.Focus(); txtA.SelectAll();
                return;
            }
            if (!long.TryParse(txtB.Text.Trim(), out long b))
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ cho b!", "Lỗi nhập liệu");
                txtB.Focus(); txtB.SelectAll();
                return;
            }

            // Tính theo tùy chọn
            if (rdoUSCLN.Checked)
            {
                long kq = GCD(a, b);
                txtKetQua.Text = kq.ToString();
            }
            else if (rdoBSCNN.Checked)
            {
                long kq = LCM(a, b);
                txtKetQua.Text = kq.ToString();
            }
            else
            {
                MessageBox.Show("Hãy chọn USCLN hoặc BSCNN trước khi Tìm.", "Thiếu tùy chọn");
            }
        }

        // ====== XỬ LÝ NÚT THOÁT ======
        private void btnThoat_Click(object sender, EventArgs e)
        {
            var ans = MessageBox.Show("Bạn có chắc muốn thoát không?",
                                      "Xác nhận",
                                      MessageBoxButtons.YesNo,
                                      MessageBoxIcon.Question);
            if (ans == DialogResult.Yes) this.Close();
        }

        // ====== CHẶN KÝ TỰ KHÔNG PHẢI SỐ (tuỳ chọn) ======
        // Cho phép: số, phím xoá (Backspace), dấu '-' ở đầu
        private void txtSo_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (char.IsControl(ch))
            {
                // Backspace, Delete, v.v.
                return;
            }

            if (char.IsDigit(ch))
            {
                return;
            }

            // Cho phép dấu '-' ở vị trí đầu tiên
            TextBox tb = sender as TextBox;
            if (ch == '-' && tb != null && tb.SelectionStart == 0 && !tb.Text.Contains("-"))
            {
                return;
            }

            // Còn lại: chặn
            e.Handled = true;
        }
    }
}
